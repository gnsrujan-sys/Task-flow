import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { db } from './db.ts';

const EPHEMERAL_SECRET = crypto.randomBytes(32).toString('hex');

function getJwtSecret(): string {
  const configured = process.env.JWT_SECRET?.trim();
  return configured && configured.length >= 16 ? configured : EPHEMERAL_SECRET;
}

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  is_active: number;
  created_at: string;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
}

export function signAccessToken(user: Pick<AuthUser, 'id' | 'email' | 'role'>): string {
  return jwt.sign(
    { sub: user.id, email: user.email, role: user.role },
    getJwtSecret(),
    { expiresIn: '24h', algorithm: 'HS256' }
  );
}

export function authenticateToken(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ status: 401, message: 'Authentication required.' });
    return;
  }

  const token = authHeader.slice(7).trim();
  if (!token) {
    res.status(401).json({ status: 401, message: 'Authentication token is missing.' });
    return;
  }

  try {
    const payload = jwt.verify(token, getJwtSecret(), { algorithms: ['HS256'] }) as {
      sub?: string;
    };

    if (!payload.sub || typeof payload.sub !== 'string') {
      res.status(401).json({ status: 401, message: 'Invalid authentication token.' });
      return;
    }

    const row = db
      .prepare('SELECT id, name, email, role, is_active, created_at FROM users WHERE id = ?')
      .get(payload.sub) as AuthUser | undefined;

    if (!row) {
      res.status(401).json({ status: 401, message: 'Account not found.' });
      return;
    }

    if (row.is_active !== 1) {
      res.status(403).json({ status: 403, message: 'This account has been deactivated.' });
      return;
    }

    req.user = row;
    next();
  } catch {
    res.status(401).json({ status: 401, message: 'Session expired or invalid. Please sign in again.' });
  }
}

export function requireAdmin(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): void {
  if (!req.user || req.user.role !== 'admin') {
    res.status(403).json({ status: 403, message: 'Administrator access required.' });
    return;
  }
  next();
}

export function isNonEmptyString(value: unknown, maxLen = 500): value is string {
  return typeof value === 'string' && value.trim().length > 0 && value.trim().length <= maxLen;
}

export function isValidEmail(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  const trimmed = value.trim().toLowerCase();
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed) && trimmed.length <= 254;
}

export function isValidDateOnly(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`));
}
