import crypto from 'node:crypto';
import { db } from './db.ts';

export type NotificationType = 'deadline' | 'assigned' | 'status_changed';

export function createNotification(params: {
  userId: string;
  message: string;
  type: NotificationType;
  taskId?: string | null;
}): void {
  const id = crypto.randomUUID();
  const createdAt = new Date().toISOString();
  db.prepare(
    `INSERT INTO notifications (id, user_id, message, type, task_id, is_read, created_at)
     VALUES (?, ?, ?, ?, ?, 0, ?)`
  ).run(id, params.userId, params.message, params.type, params.taskId ?? null, createdAt);
}

export function logActivity(params: {
  userId: string;
  actorName: string;
  action: string;
  targetTitle: string;
  projectId?: string | null;
}): void {
  const id = crypto.randomUUID();
  const createdAt = new Date().toISOString();
  db.prepare(
    `INSERT INTO activity_logs (id, user_id, actor_name, action, target_title, project_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    params.userId,
    params.actorName,
    params.action,
    params.targetTitle,
    params.projectId ?? null,
    createdAt
  );
}

export function todayDateString(): string {
  return new Date().toISOString().slice(0, 10);
}

export function addDaysDateString(baseDateStr: string, days: number): string {
  const d = new Date(`${baseDateStr}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export function ensureDeadlineNotifications(userId: string): void {
  const today = todayDateString();
  const tomorrow = addDaysDateString(today, 1);

  const dueSoonTasks = db
    .prepare(
      `SELECT id, title, due_date
       FROM tasks
       WHERE (user_id = ? OR assigned_to = ?)
         AND status != 'Completed'
         AND due_date IS NOT NULL
         AND due_date >= ?
         AND due_date <= ?`
    )
    .all(userId, userId, today, tomorrow) as Array<{
    id: string;
    title: string;
    due_date: string;
  }>;

  const existingStmt = db.prepare(
    `SELECT id FROM notifications
     WHERE user_id = ?
       AND task_id = ?
       AND type = 'deadline'
       AND substr(created_at, 1, 10) = ?`
  );

  for (const task of dueSoonTasks) {
    const alreadySent = existingStmt.get(userId, task.id, today);
    if (!alreadySent) {
      const whenLabel = task.due_date === today ? 'today' : 'tomorrow';
      createNotification({
        userId,
        type: 'deadline',
        taskId: task.id,
        message: `Deadline approaching: "${task.title}" is due ${whenLabel} (${task.due_date}).`,
      });
    }
  }
}
