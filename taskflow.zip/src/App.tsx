import { useCallback, useEffect, useState } from 'react';
import { AdminView } from './components/AdminView.tsx';
import { AnalyticsView } from './components/AnalyticsView.tsx';
import { AuthView } from './components/AuthView.tsx';
import { CalendarView } from './components/CalendarView.tsx';
import { ConfirmModal } from './components/ConfirmModal.tsx';
import { DashboardView } from './components/DashboardView.tsx';
import { KanbanView } from './components/KanbanView.tsx';
import { NotificationsView } from './components/NotificationsView.tsx';
import { ProjectsView } from './components/ProjectsView.tsx';
import { SettingsView } from './components/SettingsView.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { TaskModal } from './components/TaskModal.tsx';
import { TasksView } from './components/TasksView.tsx';
import { TopBar } from './components/TopBar.tsx';
import { api, ApiError, setAuthToken, type TaskQueryParams } from './lib/api.ts';
import type {
  AnalyticsData,
  NotificationItem,
  Project,
  Task,
  TaskStatus,
  User,
  ViewName,
} from './types/index.ts';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [darkMode, setDarkMode] = useState(false);
  const [currentView, setCurrentView] = useState<ViewName>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [tasks, setTasks] = useState<Task[]>([]);
  const [allTasks, setAllTasks] = useState<Task[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  const [taskFilters, setTaskFilters] = useState<TaskQueryParams>({
    sort: 'due_date',
    order: 'asc',
  });

  const [loadingTasks, setLoadingTasks] = useState(false);
  const [loadingAnalytics, setLoadingAnalytics] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [bannerError, setBannerError] = useState('');

  // Task Modal state
  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [modalDefaults, setModalDefaults] = useState<{
    status?: TaskStatus;
    dueDate?: string;
    projectId?: string;
  }>({});

  // Delete Confirmation Modal state
  const [deleteTarget, setDeleteTarget] = useState<Task | null>(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);

  const handleLogout = useCallback(() => {
    setAuthToken(null);
    setUser(null);
    setTasks([]);
    setAllTasks([]);
    setProjects([]);
    setAnalytics(null);
    setNotifications([]);
    setUnreadCount(0);
    setCurrentView('dashboard');
    setBannerError('');
  }, []);

  const handleApiFailure = useCallback(
    (err: unknown, fallback: string) => {
      if (err instanceof ApiError && err.status === 401) {
        handleLogout();
        return;
      }
      setBannerError(err instanceof ApiError ? err.message : fallback);
    },
    [handleLogout]
  );

  const refreshWorkspace = useCallback(async () => {
    if (!user) return;
    setLoadingAnalytics(true);
    setLoadingTasks(true);
    try {
      const [filteredTasksRes, allTasksRes, projectsRes, analyticsRes, notifRes] =
        await Promise.all([
          api.getTasks(taskFilters),
          api.getTasks({ sort: 'due_date', order: 'asc' }),
          api.getProjects(),
          api.getAnalytics(),
          api.getNotifications(),
        ]);

      setTasks(filteredTasksRes.tasks);
      setAllTasks(allTasksRes.tasks);
      setProjects(projectsRes.projects);
      setAnalytics(analyticsRes);
      setNotifications(notifRes.notifications);
      setUnreadCount(notifRes.unreadCount);
      setBannerError('');
    } catch (err) {
      handleApiFailure(err, 'Failed to load workspace data.');
    } finally {
      setLoadingAnalytics(false);
      setLoadingTasks(false);
    }
  }, [user, taskFilters, handleApiFailure]);

  const refreshFilteredTasks = useCallback(async () => {
    if (!user) return;
    setLoadingTasks(true);
    try {
      const res = await api.getTasks(taskFilters);
      setTasks(res.tasks);
    } catch (err) {
      handleApiFailure(err, 'Unable to fetch tasks.');
    } finally {
      setLoadingTasks(false);
    }
  }, [user, taskFilters, handleApiFailure]);

  useEffect(() => {
    if (user) {
      refreshWorkspace();
    }
  }, [user]); // initial load on sign in

  useEffect(() => {
    if (user) {
      refreshFilteredTasks();
    }
  }, [user, taskFilters, refreshFilteredTasks]);

  const handleAuthenticated = (token: string, authedUser: User) => {
    setAuthToken(token);
    setUser(authedUser);
    setCurrentView('dashboard');
  };

  const openNewTaskModal = (defaults?: {
    status?: TaskStatus;
    dueDate?: string;
    projectId?: string;
  }) => {
    setEditingTask(null);
    setModalDefaults(defaults ?? {});
    setTaskModalOpen(true);
  };

  const openEditTaskModal = (task: Task) => {
    setEditingTask(task);
    setModalDefaults({});
    setTaskModalOpen(true);
  };

  const handleTaskSaved = async () => {
    setTaskModalOpen(false);
    setEditingTask(null);
    await refreshWorkspace();
  };

  const handleUpdateTaskStatus = async (task: Task, nextStatus: TaskStatus) => {
    try {
      await api.updateTask(task.id, { status: nextStatus });
      await refreshWorkspace();
    } catch (err) {
      handleApiFailure(err, 'Unable to update task status.');
    }
  };

  const handleConfirmDeleteTask = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.deleteTask(deleteTarget.id);
      setDeleteTarget(null);
      await refreshWorkspace();
    } catch (err) {
      handleApiFailure(err, 'Unable to delete task.');
    } finally {
      setDeleting(false);
    }
  };

  const handleSeedSample = async () => {
    setSeeding(true);
    try {
      await api.seedSampleWorkspace();
      await refreshWorkspace();
    } catch (err) {
      handleApiFailure(err, 'Unable to load sample workspace.');
    } finally {
      setSeeding(false);
    }
  };

  const handleMarkNotificationRead = async (id: string) => {
    try {
      await api.markNotificationRead(id);
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, is_read: 1 } : n))
      );
      setUnreadCount((c) => Math.max(0, c - 1));
    } catch (err) {
      handleApiFailure(err, 'Unable to mark notification as read.');
    }
  };

  const handleMarkAllNotificationsRead = async () => {
    try {
      await api.markAllNotificationsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: 1 })));
      setUnreadCount(0);
    } catch (err) {
      handleApiFailure(err, 'Unable to mark notifications as read.');
    }
  };

  if (!user) {
    return (
      <AuthView
        darkMode={darkMode}
        onToggleTheme={() => setDarkMode((d) => !d)}
        onAuthenticated={handleAuthenticated}
      />
    );
  }

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <Sidebar
        currentView={currentView}
        user={user}
        unreadCount={unreadCount}
        darkMode={darkMode}
        mobileOpen={mobileMenuOpen}
        onSelectView={setCurrentView}
        onToggleTheme={() => setDarkMode((d) => !d)}
        onLogout={handleLogout}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar
          currentView={currentView}
          unreadCount={unreadCount}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
          onOpenNotifications={() => setCurrentView('notifications')}
          onCreateTask={() => openNewTaskModal()}
        />

        <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6">
          {bannerError && (
            <div
              role="alert"
              className="mb-5 flex items-center justify-between gap-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-300"
            >
              <span>{bannerError}</span>
              <button
                type="button"
                onClick={() => setBannerError('')}
                className="text-xs font-semibold underline"
              >
                Dismiss
              </button>
            </div>
          )}

          {currentView === 'dashboard' && (
            <DashboardView
              analytics={analytics}
              loading={loadingAnalytics}
              darkMode={darkMode}
              seeding={seeding}
              onSeedSample={handleSeedSample}
              onCreateTask={() => openNewTaskModal()}
              onEditTask={openEditTaskModal}
              onToggleComplete={(t) =>
                handleUpdateTaskStatus(
                  t,
                  t.status === 'Completed' ? 'Pending' : 'Completed'
                )
              }
              onNavigate={setCurrentView}
            />
          )}

          {currentView === 'tasks' && (
            <TasksView
              tasks={tasks}
              projects={projects}
              loading={loadingTasks}
              filters={taskFilters}
              onChangeFilters={setTaskFilters}
              onCreateTask={() => openNewTaskModal()}
              onEditTask={openEditTaskModal}
              onUpdateStatus={handleUpdateTaskStatus}
              onRequestDelete={setDeleteTarget}
            />
          )}

          {currentView === 'board' && (
            <KanbanView
              tasks={allTasks}
              onCreateTaskInStatus={(status) => openNewTaskModal({ status })}
              onEditTask={openEditTaskModal}
              onMoveTask={handleUpdateTaskStatus}
            />
          )}

          {currentView === 'calendar' && (
            <CalendarView
              tasks={allTasks}
              onEditTask={openEditTaskModal}
              onCreateTaskOnDate={(dueDate) => openNewTaskModal({ dueDate })}
            />
          )}

          {currentView === 'projects' && (
            <ProjectsView
              projects={projects}
              tasks={allTasks}
              currentUser={user}
              onRefresh={refreshWorkspace}
              onCreateProjectTask={(projectId) => openNewTaskModal({ projectId })}
              onEditTask={openEditTaskModal}
            />
          )}

          {currentView === 'analytics' && (
            <AnalyticsView
              analytics={analytics}
              projectCount={projects.length}
              darkMode={darkMode}
            />
          )}

          {currentView === 'notifications' && (
            <NotificationsView
              notifications={notifications}
              unreadCount={unreadCount}
              onMarkRead={handleMarkNotificationRead}
              onMarkAllRead={handleMarkAllNotificationsRead}
            />
          )}

          {currentView === 'settings' && (
            <SettingsView
              user={user}
              darkMode={darkMode}
              onToggleTheme={() => setDarkMode((d) => !d)}
              onUserUpdated={setUser}
            />
          )}

          {currentView === 'admin' && user.role === 'admin' && (
            <AdminView currentUser={user} onRefreshWorkspace={refreshWorkspace} />
          )}
        </main>
      </div>

      <TaskModal
        open={taskModalOpen}
        task={editingTask}
        projects={projects}
        currentUser={user}
        defaultStatus={modalDefaults.status}
        defaultDueDate={modalDefaults.dueDate}
        defaultProjectId={modalDefaults.projectId}
        onClose={() => {
          setTaskModalOpen(false);
          setEditingTask(null);
        }}
        onSaved={handleTaskSaved}
      />

      <ConfirmModal
        open={Boolean(deleteTarget)}
        title="Delete Task"
        description={`Are you sure you want to delete "${deleteTarget?.title}"? This action cannot be undone.`}
        confirmLabel="Delete Task"
        destructive
        busy={deleting}
        onConfirm={handleConfirmDeleteTask}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
