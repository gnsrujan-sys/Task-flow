import { useCallback, useEffect, useState } from 'react';
import { Search, Trash2 } from 'lucide-react';
import { api, ApiError } from '../lib/api.ts';
import type { AdminProjectRow, AdminUserRow, User } from '../types/index.ts';
import { ConfirmModal } from './ConfirmModal.tsx';

interface AdminViewProps {
  currentUser: User;
  onRefreshWorkspace: () => Promise<void>;
}

export function AdminView({ currentUser, onRefreshWorkspace }: AdminViewProps) {
  const [users, setUsers] = useState<AdminUserRow[]>([]);
  const [projects, setProjects] = useState<AdminProjectRow[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [confirmProject, setConfirmProject] = useState<AdminProjectRow | null>(null);
  const [busy, setBusy] = useState(false);

  const loadAdminData = useCallback(async (query: string) => {
    setLoading(true);
    setError('');
    try {
      const [uRes, pRes] = await Promise.all([
        api.adminGetUsers(query),
        api.adminGetProjects(),
      ]);
      setUsers(uRes.users);
      setProjects(pRes.projects);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Unable to load administration data.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAdminData(search);
  }, [loadAdminData, search]);

  const handleToggleActive = async (target: AdminUserRow) => {
    setError('');
    try {
      await api.adminUpdateUser(target.id, { is_active: target.is_active !== 1 });
      await loadAdminData(search);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Unable to update user status.');
    }
  };

  const handleToggleRole = async (target: AdminUserRow) => {
    setError('');
    try {
      const nextRole = target.role === 'admin' ? 'user' : 'admin';
      await api.adminUpdateUser(target.id, { role: nextRole });
      await loadAdminData(search);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Unable to update user role.');
    }
  };

  const handleDeleteProject = async () => {
    if (!confirmProject) return;
    setBusy(true);
    setError('');
    try {
      await api.adminDeleteProject(confirmProject.id);
      setConfirmProject(null);
      await Promise.all([loadAdminData(search), onRefreshWorkspace()]);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Unable to delete project.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      {error && (
        <div
          role="alert"
          className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-300"
        >
          {error}
        </div>
      )}

      {/* User Management */}
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 px-5 py-4 dark:border-slate-800">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              Registered Users ({users.length})
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Search accounts, manage roles, or deactivate access.
            </p>
          </div>
          <div className="relative w-full sm:w-64">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name or email..."
              aria-label="Search users"
              className="w-full rounded-lg border border-slate-200 bg-white py-1.5 pr-3 pl-9 text-sm text-slate-900 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>
        </div>

        {loading ? (
          <div className="p-6 text-sm text-slate-500 dark:text-slate-400">Loading users...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                  <th className="py-3 pr-3 pl-5">User</th>
                  <th className="px-3 py-3">Role</th>
                  <th className="px-3 py-3">Status</th>
                  <th className="px-3 py-3 text-right">Tasks</th>
                  <th className="px-3 py-3 text-right">Projects</th>
                  <th className="py-3 pr-5 pl-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {users.map((u) => {
                  const isSelf = u.id === currentUser.id;
                  return (
                    <tr key={u.id}>
                      <td className="py-3 pr-3 pl-5">
                        <p className="font-medium text-slate-900 dark:text-slate-100">{u.name}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{u.email}</p>
                      </td>
                      <td className="px-3 py-3 text-xs font-medium text-slate-700 dark:text-slate-300">
                        {u.role === 'admin' ? 'Administrator' : 'Member'}
                      </td>
                      <td className="px-3 py-3 text-xs font-medium">
                        <span
                          className={
                            u.is_active === 1
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-red-600 dark:text-red-400'
                          }
                        >
                          {u.is_active === 1 ? 'Active' : 'Deactivated'}
                        </span>
                      </td>
                      <td className="px-3 py-3 text-right font-mono text-xs tabular-nums text-slate-600 dark:text-slate-400">
                        {u.task_count}
                      </td>
                      <td className="px-3 py-3 text-right font-mono text-xs tabular-nums text-slate-600 dark:text-slate-400">
                        {u.owned_projects}
                      </td>
                      <td className="py-3 pr-5 pl-3 text-right">
                        {isSelf ? (
                          <span className="text-xs text-slate-400">Current session</span>
                        ) : (
                          <div className="inline-flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleToggleRole(u)}
                              className="whitespace-nowrap rounded-md border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                            >
                              {u.role === 'admin' ? 'Make Member' : 'Make Admin'}
                            </button>
                            <button
                              type="button"
                              onClick={() => handleToggleActive(u)}
                              className={`whitespace-nowrap rounded-md border px-2.5 py-1 text-xs font-medium ${
                                u.is_active === 1
                                  ? 'border-red-200 text-red-600 hover:bg-red-50 dark:border-red-900/50 dark:text-red-400 dark:hover:bg-red-950/30'
                                  : 'border-emerald-200 text-emerald-700 hover:bg-emerald-50 dark:border-emerald-900/50 dark:text-emerald-400 dark:hover:bg-emerald-950/30'
                              }`}
                            >
                              {u.is_active === 1 ? 'Deactivate' : 'Activate'}
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Platform Projects */}
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="border-b border-slate-200 px-5 py-4 dark:border-slate-800">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            All Platform Projects ({projects.length})
          </h2>
        </div>
        {projects.length === 0 ? (
          <p className="px-5 py-8 text-center text-xs text-slate-500 dark:text-slate-400">
            No projects created on the platform yet.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-medium text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                  <th className="py-3 pr-3 pl-5">Project</th>
                  <th className="px-3 py-3">Owner</th>
                  <th className="px-3 py-3 text-right">Members</th>
                  <th className="px-3 py-3 text-right">Tasks</th>
                  <th className="py-3 pr-5 pl-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {projects.map((p) => (
                  <tr key={p.id}>
                    <td className="py-3 pr-3 pl-5">
                      <p className="font-medium text-slate-900 dark:text-slate-100">
                        {p.project_name}
                      </p>
                      <p className="truncate text-xs text-slate-500 dark:text-slate-400">
                        {p.description || 'No description'}
                      </p>
                    </td>
                    <td className="px-3 py-3 text-xs text-slate-600 dark:text-slate-400">
                      {p.owner_name} ({p.owner_email})
                    </td>
                    <td className="px-3 py-3 text-right font-mono text-xs tabular-nums text-slate-600 dark:text-slate-400">
                      {p.member_count}
                    </td>
                    <td className="px-3 py-3 text-right font-mono text-xs tabular-nums text-slate-600 dark:text-slate-400">
                      {p.task_count}
                    </td>
                    <td className="py-3 pr-5 pl-3 text-right">
                      <button
                        type="button"
                        onClick={() => setConfirmProject(p)}
                        className="inline-flex items-center gap-1 rounded-md p-1.5 text-slate-500 hover:bg-red-50 hover:text-red-600 dark:text-slate-400 dark:hover:bg-red-950/40 dark:hover:text-red-400"
                        aria-label={`Delete project ${p.project_name}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <ConfirmModal
        open={Boolean(confirmProject)}
        title="Delete Project"
        description={`Permanently delete project "${confirmProject?.project_name}"? Tasks in this project will be unlinked.`}
        confirmLabel="Delete Project"
        destructive
        busy={busy}
        onConfirm={handleDeleteProject}
        onCancel={() => setConfirmProject(null)}
      />
    </div>
  );
}
