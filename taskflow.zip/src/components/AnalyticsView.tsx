import { Bar, Doughnut } from 'react-chartjs-2';
import '../lib/chartSetup.ts';
import type { AnalyticsData } from '../types/index.ts';

interface AnalyticsViewProps {
  analytics: AnalyticsData | null;
  projectCount: number;
  darkMode: boolean;
}

export function AnalyticsView({ analytics, projectCount, darkMode }: AnalyticsViewProps) {
  if (!analytics) {
    return (
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {Array.from({ length: 3 }).map((_, idx) => (
          <div
            key={idx}
            className="h-72 animate-pulse rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900"
          />
        ))}
      </div>
    );
  }

  const { counts, byStatus, byPriority, weeklyCompleted } = analytics;
  const completionRate =
    counts.total > 0 ? Math.round((counts.completed / counts.total) * 100) : 0;

  const textColor = darkMode ? '#94A3B8' : '#475569';
  const gridColor = darkMode ? 'rgba(148, 163, 184, 0.12)' : 'rgba(15, 23, 42, 0.06)';

  const statusData = {
    labels: ['Pending', 'In Progress', 'Completed'],
    datasets: [
      {
        data: [byStatus.Pending, byStatus['In Progress'], byStatus.Completed],
        backgroundColor: ['#94A3B8', '#D97706', '#16A34A'],
        borderColor: darkMode ? '#0F172A' : '#FFFFFF',
        borderWidth: 2,
      },
    ],
  };

  const priorityData = {
    labels: ['High', 'Medium', 'Low'],
    datasets: [
      {
        label: 'Tasks',
        data: [byPriority.High, byPriority.Medium, byPriority.Low],
        backgroundColor: ['#DC2626', '#D97706', '#64748B'],
        borderRadius: 6,
      },
    ],
  };

  const weeklyData = {
    labels: weeklyCompleted.map((w) => w.label),
    datasets: [
      {
        label: 'Completed Tasks',
        data: weeklyCompleted.map((w) => w.count),
        backgroundColor: '#2563EB',
        borderRadius: 6,
      },
    ],
  };

  return (
    <div className="space-y-6">
      <section className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white px-5 py-4 dark:border-slate-800 dark:bg-slate-900">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Completion Rate</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-emerald-600 tabular-nums dark:text-emerald-400">
            {completionRate}%
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white px-5 py-4 dark:border-slate-800 dark:bg-slate-900">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Active Workload</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 tabular-nums dark:text-white">
            {counts.pending + counts.inProgress}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white px-5 py-4 dark:border-slate-800 dark:bg-slate-900">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Overdue Tasks</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-red-600 tabular-nums dark:text-red-400">
            {counts.overdue}
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white px-5 py-4 dark:border-slate-800 dark:bg-slate-900">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Projects</p>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 tabular-nums dark:text-white">
            {projectCount}
          </p>
        </div>
      </section>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <section className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-7 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            Tasks Completed per Week
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Weekly completion volume across the last 8 weeks
          </p>
          <div className="mt-4 h-64">
            <Bar
              data={weeklyData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                  x: { ticks: { color: textColor }, grid: { display: false } },
                  y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1, color: textColor },
                    grid: { color: gridColor },
                  },
                },
              }}
            />
          </div>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-5 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            Tasks by Status
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Current distribution across workflow stages
          </p>
          <div className="mt-4 flex h-64 items-center justify-center">
            <div className="h-56 w-56">
              <Doughnut
                data={statusData}
                options={{
                  responsive: true,
                  maintainAspectRatio: true,
                  cutout: '62%',
                  plugins: {
                    legend: {
                      position: 'bottom',
                      labels: { color: textColor, boxWidth: 12, padding: 14 },
                    },
                  },
                }}
              />
            </div>
          </div>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-12 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            Tasks by Priority
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Breakdown of High, Medium, and Low priority workload
          </p>
          <div className="mt-4 h-56">
            <Bar
              data={priorityData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                  x: { ticks: { color: textColor }, grid: { display: false } },
                  y: {
                    beginAtZero: true,
                    ticks: { stepSize: 1, color: textColor },
                    grid: { color: gridColor },
                  },
                },
              }}
            />
          </div>
        </section>
      </div>
    </div>
  );
}
