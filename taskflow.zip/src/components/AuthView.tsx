import { useEffect, useState, type FormEvent } from 'react';
import { CheckSquare, Moon, Shield, Sun } from 'lucide-react';
import { api, ApiError } from '../lib/api.ts';
import type { User } from '../types/index.ts';

interface AuthViewProps {
  darkMode: boolean;
  onToggleTheme: () => void;
  onAuthenticated: (token: string, user: User) => void;
}

type AuthMode = 'login' | 'register' | 'claim-admin';

export function AuthView({ darkMode, onToggleTheme, onAuthenticated }: AuthViewProps) {
  const [mode, setMode] = useState<AuthMode>('login');
  const [adminClaimed, setAdminClaimed] = useState<boolean>(true);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api
      .getBootstrapStatus()
      .then((res) => {
        setAdminClaimed(res.adminClaimed);
        if (!res.adminClaimed) {
          setMode('claim-admin');
        }
      })
      .catch(() => {
        setAdminClaimed(true);
      });
  }, []);

  const switchMode = (next: AuthMode) => {
    setMode(next);
    setError('');
    setPassword('');
    setConfirmPassword('');
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');

    if (mode !== 'login') {
      if (!name.trim()) {
        setError('Please enter your full name.');
        return;
      }
      if (password.length < 8) {
        setError('Password must be at least 8 characters long.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Passwords do not match.');
        return;
      }
    }

    setLoading(true);
    try {
      if (mode === 'login') {
        const res = await api.login({ email: email.trim(), password });
        onAuthenticated(res.token, res.user);
      } else if (mode === 'claim-admin') {
        const res = await api.claimAdmin({
          name: name.trim(),
          email: email.trim(),
          password,
        });
        onAuthenticated(res.token, res.user);
      } else {
        const res = await api.register({
          name: name.trim(),
          email: email.trim(),
          password,
        });
        onAuthenticated(res.token, res.user);
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Authentication failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      <header className="mx-auto flex max-w-6xl items-center justify-between gap-8 px-6 py-5">
        <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
          <CheckSquare className="h-6 w-6 text-blue-600" aria-hidden="true" />
          <span className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-white">
            TaskFlow
          </span>
        </div>
        <button
          type="button"
          onClick={onToggleTheme}
          className="flex items-center gap-2 whitespace-nowrap shrink-0 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-blue-600 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
          aria-label="Toggle color theme"
        >
          {darkMode ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}
          <span>{darkMode ? 'Light' : 'Dark'}</span>
        </button>
      </header>

      <main className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-12 px-6 py-8 lg:grid-cols-12 lg:py-16">
        <div className="lg:col-span-6">
          <p className="text-xs font-medium text-blue-600 dark:text-blue-400">
            Personal &amp; Small Team Workspace
          </p>
          <h1
            className="mt-3 font-display text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl dark:text-white"
            style={{ textWrap: 'balance' }}
          >
            Organize tasks, coordinate projects, and ship on schedule.
          </h1>
          <p className="mt-4 max-w-xl text-base leading-relaxed text-slate-600 dark:text-slate-400">
            Replace scattered notes and spreadsheets with one focused workspace featuring
            priorities, deadlines, Kanban workflows, team assignments, and completion analytics.
          </p>

          <dl className="mt-10 grid grid-cols-1 gap-6 border-t border-slate-200 pt-8 sm:grid-cols-3 dark:border-slate-800">
            <div>
              <dt className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Views Included
              </dt>
              <dd className="mt-1 text-sm font-semibold text-slate-900 dark:text-slate-100">
                List · Board · Calendar
              </dd>
            </div>
            <div>
              <dt className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Deadline Alerts
              </dt>
              <dd className="mt-1 text-sm font-semibold text-slate-900 dark:text-slate-100">
                24-Hour &amp; Overdue
              </dd>
            </div>
            <div>
              <dt className="text-xs font-medium text-slate-500 dark:text-slate-400">
                Analytics
              </dt>
              <dd className="mt-1 text-sm font-semibold text-slate-900 dark:text-slate-100">
                Weekly Completion
              </dd>
            </div>
          </dl>
        </div>

        <div className="lg:col-span-6">
          <div className="mx-auto max-w-md rounded-xl border border-slate-200 bg-white p-6 sm:p-8 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
              <button
                type="button"
                onClick={() => switchMode('login')}
                className={`flex-1 whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                  mode === 'login'
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => switchMode('register')}
                className={`flex-1 whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                  mode === 'register'
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
              >
                Create Account
              </button>
              {!adminClaimed && (
                <button
                  type="button"
                  onClick={() => switchMode('claim-admin')}
                  className={`flex-1 whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                    mode === 'claim-admin'
                      ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-white'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                  }`}
                >
                  Admin Setup
                </button>
              )}
            </div>

            <div className="mt-6">
              <h2 className="font-display text-xl font-semibold text-slate-900 dark:text-white">
                {mode === 'login'
                  ? 'Welcome back'
                  : mode === 'claim-admin'
                  ? 'Initialize Workspace Admin'
                  : 'Create your account'}
              </h2>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                {mode === 'login'
                  ? 'Enter your credentials to access your tasks and projects.'
                  : mode === 'claim-admin'
                  ? 'First-run setup: claim the workspace administrator account.'
                  : 'Start tracking tasks and collaborating in under a minute.'}
              </p>
            </div>

            {mode === 'claim-admin' && (
              <div className="mt-4 flex items-start gap-2.5 rounded-lg border border-blue-200 bg-blue-50/70 p-3 text-xs leading-relaxed text-blue-900 dark:border-blue-900/60 dark:bg-blue-950/30 dark:text-blue-200">
                <Shield className="mt-0.5 h-4 w-4 shrink-0 text-blue-600 dark:text-blue-400" />
                <span>
                  No administrator exists yet. Creating this account sets you as the workspace
                  admin and locks this setup form.
                </span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="mt-5 space-y-4">
              {error && (
                <div
                  role="alert"
                  className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-300"
                >
                  {error}
                </div>
              )}

              {mode !== 'login' && (
                <div>
                  <label
                    htmlFor="auth-name"
                    className="block text-sm font-medium text-slate-700 dark:text-slate-300"
                  >
                    Full Name
                  </label>
                  <input
                    id="auth-name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Alex Morgan"
                    required
                    className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  />
                </div>
              )}

              <div>
                <label
                  htmlFor="auth-email"
                  className="block text-sm font-medium text-slate-700 dark:text-slate-300"
                >
                  Email Address
                </label>
                <input
                  id="auth-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@company.com"
                  required
                  className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              <div>
                <label
                  htmlFor="auth-password"
                  className="block text-sm font-medium text-slate-700 dark:text-slate-300"
                >
                  Password
                </label>
                <input
                  id="auth-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={mode === 'login' ? 'Enter your password' : 'Minimum 8 characters'}
                  required
                  minLength={mode === 'login' ? 1 : 8}
                  className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>

              {mode !== 'login' && (
                <div>
                  <label
                    htmlFor="auth-confirm-password"
                    className="block text-sm font-medium text-slate-700 dark:text-slate-300"
                  >
                    Confirm Password
                  </label>
                  <input
                    id="auth-confirm-password"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    required
                    minLength={8}
                    className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full whitespace-nowrap rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 disabled:opacity-50"
              >
                {loading
                  ? 'Please wait...'
                  : mode === 'login'
                  ? 'Sign In'
                  : mode === 'claim-admin'
                  ? 'Create Admin & Continue'
                  : 'Create Account'}
              </button>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
}
