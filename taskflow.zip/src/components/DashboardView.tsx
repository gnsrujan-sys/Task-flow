import { ArrowRight, CalendarClock, CheckCircle2, Plus, Sparkles } from 'lucide-react';
import { Doughnut } from 'react-chartjs-2';
import '../lib/chartSetup.ts';
import { formatDueDate, formatRelativeTime, priorityTextColor } from '../lib/format.ts';
import type { AnalyticsData, Task, ViewName } from '../types/index.ts';

interface DashboardViewProps {
  analytics: AnalyticsData | null;
  loading: boolean;
  darkMode: boolean;
  seeding: boolean;
  onSeedSample: () => void;
  onCreateTask: () => void;
  onEditTask: (task: Task) => void;
  onToggleComplete: (task: Task) => void;
  onNavigate: (view: ViewName) => void;
}

export function DashboardView({
  analytics,
  loading,
  darkMode,
  seeding,
  onSeedSample,
  onCreateTask,
  onEditTask,
  onToggleComplete,
  onNavigate,
}: DashboardViewProps) {
  if (loading && !analytics) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {Array.from({ length: 5 }).map((_, i) => (
            <div
              key={i}
              className="h-24 animate-pulse rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900"
            />
          ))}
        </div>
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="h-80 animate-pulse rounded-xl border border-slate-200 bg-white lg:col-span-7 dark:border-slate-800 dark:bg-slate-900" />
          <div className="h-80 animate-pulse rounded-xl border border-slate-200 bg-white lg:col-span-5 dark:border-slate-800 dark:bg-slate-900" />
        </div>
      </div>
    );
  }

  const counts = analytics?.counts ?? {
    total: 0,
    pending: 0,
    inProgress: 0,
    completed: 0,
    overdue: 0,
  };

  const kpis = [
    { label: 'Total Tasks', value: counts.total, accent: 'text-slate-900 dark:text-white' },
    { label: 'Pending', value: counts.pending, accent: 'text-slate-700 dark:text-slate-300' },
    { label: 'In Progress', value: counts.inProgress, accent: 'text-amber-600 dark:text-amber-400' },
    { label: 'Completed', value: counts.completed, accent: 'text-emerald-600 dark:text-emerald-400' },
    { label: 'Overdue', value: counts.overdue, accent: 'text-red-600 dark:text-red-400' },
  ];

  const hasData = counts.total > 0;

  const statusChartData = {
    labels: ['Pending', 'In Progress', 'Completed'],
    datasets: [
      {
        data: [counts.pending, counts.inProgress, counts.completed],
        backgroundColor: ['#94A3B8', '#D97706', '#16A34A'],
        borderColor: darkMode ? '#0F172A' : '#FFFFFF',
        borderWidth: 2,
      },
    ],
  };

  return (
    <div className="space-y-6">
      {/* KPI strip */}
      <section aria-label="Workload summary">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
          {kpis.map((kpi) => (
            <div
              key={kpi.label}
              className="rounded-xl border border-slate-200 bg-white px-5 py-4 dark:border-slate-800 dark:bg-slate-900"
            >
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">{kpi.label}</p>
              <p className={`mt-2 font-mono text-2xl font-semibold tabular-nums ${kpi.accent}`}>
                {kpi.value}
              </p>
            </div>
          ))}
        </div>
      </section>

      {!hasData ? (
        <section className="rounded-xl border border-slate-200 bg-white p-8 text-center dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-xl font-semibold text-slate-900 dark:text-white">
            Your workspace is ready
          </h2>
          <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-slate-600 dark:text-slate-400">
            Create your first task to start tracking deadlines and progress, or load sample
            projects and tasks to explore charts and Kanban workflows immediately.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={onCreateTask}
              className="flex items-center gap-2 whitespace-nowrap rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-700 focus-visible:outline-2 focus-visible:outline-blue-600"
            >
              <Plus className="h-4 w-4" />
              <span>Create First Task</span>
            </button>
            <button
              type="button"
              onClick={onSeedSample}
              disabled={seeding}
              className="flex items-center gap-2 whitespace-nowrap rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 transition-colors hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-blue-600 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <Sparkles className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              <span>{seeding ? 'Loading Sample...' : 'Load Sample Workspace'}</span>
            </button>
          </div>
        </section>
      ) : (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Upcoming tasks (next 7 days) */}
          <section className="rounded-xl border border-slate-200 bg-white lg:col-span-7 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <CalendarClock className="h-4 w-4 text-slate-500 dark:text-slate-400" />
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                  Upcoming Deadlines (Next 7 Days)
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('tasks')}
                className="flex items-center gap-1 whitespace-nowrap text-xs font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400"
              >
                <span>All Tasks</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>

            {analytics?.upcomingTasks.length === 0 ? (
              <div className="px-5 py-10 text-center">
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  No pending tasks due in the next 7 days.
                </p>
              </div>
            ) : (
              <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                {analytics?.upcomingTasks.map((task) => (
                  <li
                    key={task.id}
                    className="flex items-center justify-between gap-4 px-5 py-3.5 transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/50"
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      <button
                        type="button"
                        onClick={() => onToggleComplete(task)}
                        className="mt-0.5 shrink-0 text-slate-400 transition-colors hover:text-emerald-600 focus-visible:outline-2 focus-visible:outline-blue-600"
                        aria-label={`Mark "${task.title}" as completed`}
                      >
                        <CheckCircle2 className="h-4 w-4" />
                      </button>
                      <div className="min-w-0">
                        <button
                          type="button"
                          onClick={() => onEditTask(task)}
                          className="block truncate text-left text-sm font-medium text-slate-900 hover:text-blue-600 dark:text-slate-100 dark:hover:text-blue-400"
                        >
                          {task.title}
                        </button>
                        <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                          <span className={priorityTextColor(task.priority)}>{task.priority}</span>
                          <span aria-hidden="true">·</span>
                          <span>{task.status}</span>
                          {task.project_name && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span>{task.project_name}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <span className="shrink-0 font-mono text-xs text-slate-600 tabular-nums dark:text-slate-300">
                      {formatDueDate(task.due_date)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </section>

          {/* Status Breakdown + Recent Activity */}
          <div className="space-y-6 lg:col-span-5">
            <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                  Status Overview
                </h2>
                <button
                  type="button"
                  onClick={() => onNavigate('analytics')}
                  className="flex items-center gap-1 whitespace-nowrap text-xs font-medium text-blue-600 hover:text-blue-700 dark:text-blue-400"
                >
                  <span>Full Analytics</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
              <div className="mt-4 flex items-center gap-6">
                <div className="h-36 w-36 shrink-0">
                  <Doughnut
                    data={statusChartData}
                    options={{
                      responsive: true,
                      maintainAspectRatio: true,
                      cutout: '66%',
                      plugins: {
                        legend: { display: false },
                      },
                    }}
                  />
                </div>
                <dl className="flex-1 space-y-2.5 text-sm">
                  <div className="flex items-center justify-between">
                    <dt className="text-slate-600 dark:text-slate-400">Pending</dt>
                    <dd className="font-mono font-medium text-slate-900 tabular-nums dark:text-slate-100">
                      {counts.pending}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between">
                    <dt className="text-slate-600 dark:text-slate-400">In Progress</dt>
                    <dd className="font-mono font-medium text-amber-600 tabular-nums dark:text-amber-400">
                      {counts.inProgress}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between">
                    <dt className="text-slate-600 dark:text-slate-400">Completed</dt>
                    <dd className="font-mono font-medium text-emerald-600 tabular-nums dark:text-emerald-400">
                      {counts.completed}
                    </dd>
                  </div>
                </dl>
              </div>
            </section>

            <section className="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
              <div className="border-b border-slate-100 px-5 py-4 dark:border-slate-800">
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                  Recent Activity
                </h2>
              </div>
              {analytics?.recentActivity.length === 0 ? (
                <p className="px-5 py-6 text-sm text-slate-500 dark:text-slate-400">
                  No activity recorded yet.
                </p>
              ) : (
                <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                  {analytics?.recentActivity.slice(0, 6).map((log) => (
                    <li key={log.id} className="px-5 py-3 text-sm">
                      <p className="text-slate-800 dark:text-slate-200">
                        <span className="font-medium">{log.actor_name}</span>{' '}
                        <span className="text-slate-600 dark:text-slate-400">{log.action}</span>{' '}
                        <span className="font-medium">"{log.target_title}"</span>
                      </p>
                      <p className="mt-0.5 font-mono text-xs text-slate-400 tabular-nums dark:text-slate-500">
                        {formatRelativeTime(log.created_at)}
                      </p>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </div>
        </div>
      )}
    </div>
  );
}
