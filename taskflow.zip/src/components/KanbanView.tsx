import { useState } from 'react';
import { Plus } from 'lucide-react';
import { formatDueDate, priorityTextColor } from '../lib/format.ts';
import type { Task, TaskStatus } from '../types/index.ts';

interface KanbanViewProps {
  tasks: Task[];
  onCreateTaskInStatus: (status: TaskStatus) => void;
  onEditTask: (task: Task) => void;
  onMoveTask: (task: Task, nextStatus: TaskStatus) => void;
}

const COLUMNS: Array<{ status: TaskStatus; label: string }> = [
  { status: 'Pending', label: 'Pending' },
  { status: 'In Progress', label: 'In Progress' },
  { status: 'Completed', label: 'Completed' },
];

export function KanbanView({
  tasks,
  onCreateTaskInStatus,
  onEditTask,
  onMoveTask,
}: KanbanViewProps) {
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [dragOverCol, setDragOverCol] = useState<TaskStatus | null>(null);

  const handleDrop = (targetStatus: TaskStatus) => {
    if (!draggingId) return;
    const task = tasks.find((t) => t.id === draggingId);
    setDraggingId(null);
    setDragOverCol(null);
    if (task && task.status !== targetStatus) {
      onMoveTask(task, targetStatus);
    }
  };

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
      {COLUMNS.map((col) => {
        const colTasks = tasks.filter((t) => t.status === col.status);
        const isDragOver = dragOverCol === col.status;

        return (
          <section
            key={col.status}
            onDragOver={(e) => {
              e.preventDefault();
              if (dragOverCol !== col.status) setDragOverCol(col.status);
            }}
            onDragLeave={() => {
              if (dragOverCol === col.status) setDragOverCol(null);
            }}
            onDrop={(e) => {
              e.preventDefault();
              handleDrop(col.status);
            }}
            className={`flex min-h-[28rem] flex-col rounded-xl border p-4 transition-colors ${
              isDragOver
                ? 'border-blue-500 bg-blue-50/40 dark:border-blue-500 dark:bg-blue-950/20'
                : 'border-slate-200 bg-slate-100/60 dark:border-slate-800 dark:bg-slate-900/60'
            }`}
          >
            <div className="mb-3 flex items-center justify-between px-1">
              <div className="flex items-center gap-2">
                <h2 className="font-display text-sm font-semibold text-slate-900 dark:text-white">
                  {col.label}
                </h2>
                <span className="font-mono text-xs text-slate-500 tabular-nums dark:text-slate-400">
                  {colTasks.length}
                </span>
              </div>
              <button
                type="button"
                onClick={() => onCreateTaskInStatus(col.status)}
                className="rounded-md p-1.5 text-slate-500 transition-colors hover:bg-white hover:text-slate-900 focus-visible:outline-2 focus-visible:outline-blue-600 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
                aria-label={`Add task to ${col.label}`}
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>

            <div className="flex-1 space-y-3">
              {colTasks.length === 0 ? (
                <div className="rounded-lg border border-dashed border-slate-300 px-4 py-8 text-center text-xs text-slate-500 dark:border-slate-700 dark:text-slate-400">
                  Drop a task here or click + to add one.
                </div>
              ) : (
                colTasks.map((task) => (
                  <article
                    key={task.id}
                    draggable
                    onDragStart={(e) => {
                      setDraggingId(task.id);
                      e.dataTransfer.effectAllowed = 'move';
                      e.dataTransfer.setData('text/plain', task.id);
                    }}
                    onDragEnd={() => {
                      setDraggingId(null);
                      setDragOverCol(null);
                    }}
                    className={`cursor-grab rounded-lg border border-slate-200 bg-white p-3.5 transition-colors hover:border-slate-300 active:cursor-grabbing dark:border-slate-800 dark:bg-slate-950 dark:hover:border-slate-700 ${
                      draggingId === task.id ? 'opacity-50' : ''
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => onEditTask(task)}
                      className="block w-full text-left text-sm font-medium text-slate-900 hover:text-blue-600 dark:text-slate-100 dark:hover:text-blue-400"
                    >
                      {task.title}
                    </button>

                    <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className={priorityTextColor(task.priority)}>{task.priority}</span>
                      <span aria-hidden="true">·</span>
                      <span>{task.project_name || 'Personal'}</span>
                      {task.due_date && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span
                            className={`font-mono tabular-nums ${
                              task.is_overdue ? 'font-semibold text-red-600 dark:text-red-400' : ''
                            }`}
                          >
                            {formatDueDate(task.due_date)}
                            {task.is_overdue ? ' (Overdue)' : ''}
                          </span>
                        </>
                      )}
                    </div>

                    <div className="mt-3 flex items-center justify-between border-t border-slate-100 pt-2.5 text-xs dark:border-slate-800">
                      <span className="truncate text-slate-500 dark:text-slate-400">
                        {task.assignee_name || 'Unassigned'}
                      </span>
                      <select
                        aria-label={`Move "${task.title}" to column`}
                        value={task.status}
                        onChange={(e) => onMoveTask(task, e.target.value as TaskStatus)}
                        className="rounded border border-slate-200 bg-slate-50 px-2 py-0.5 text-xs text-slate-700 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300"
                      >
                        <option value="Pending">Pending</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                      </select>
                    </div>
                  </article>
                ))
              )}
            </div>
          </section>
        );
      })}
    </div>
  );
}
