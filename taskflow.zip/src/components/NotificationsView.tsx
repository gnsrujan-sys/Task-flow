import { useState } from 'react';
import { Bell, Check, CheckCheck } from 'lucide-react';
import { formatRelativeTime } from '../lib/format.ts';
import type { NotificationItem } from '../types/index.ts';

interface NotificationsViewProps {
  notifications: NotificationItem[];
  unreadCount: number;
  onMarkRead: (id: string) => void;
  onMarkAllRead: () => void;
}

export function NotificationsView({
  notifications,
  unreadCount,
  onMarkRead,
  onMarkAllRead,
}: NotificationsViewProps) {
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const visible =
    filter === 'unread'
      ? notifications.filter((n) => n.is_read === 0)
      : notifications;

  const typeLabel = (type: NotificationItem['type']) => {
    switch (type) {
      case 'deadline':
        return 'Deadline Reminder';
      case 'assigned':
        return 'Assignment';
      case 'status_changed':
        return 'Status Update';
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
          <button
            type="button"
            onClick={() => setFilter('all')}
            className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
              filter === 'all'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            All ({notifications.length})
          </button>
          <button
            type="button"
            onClick={() => setFilter('unread')}
            className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
              filter === 'unread'
                ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-white'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            Unread ({unreadCount})
          </button>
        </div>

        {unreadCount > 0 && (
          <button
            type="button"
            onClick={onMarkAllRead}
            className="flex items-center gap-1.5 whitespace-nowrap rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <CheckCheck className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            <span>Mark all as read</span>
          </button>
        )}
      </div>

      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        {visible.length === 0 ? (
          <div className="px-6 py-12 text-center">
            <Bell className="mx-auto h-6 w-6 text-slate-400" />
            <p className="mt-3 text-sm font-medium text-slate-900 dark:text-slate-100">
              {filter === 'unread' ? 'No unread notifications' : 'No notifications yet'}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Alerts appear here when a deadline is within 24 hours, a task is assigned, or a
              teammate updates task status.
            </p>
          </div>
        ) : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {visible.map((item) => {
              const unread = item.is_read === 0;
              return (
                <li
                  key={item.id}
                  className={`flex items-start justify-between gap-4 px-5 py-4 transition-colors ${
                    unread ? 'bg-blue-50/30 dark:bg-blue-950/20' : ''
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span
                        className={
                          item.type === 'deadline'
                            ? 'font-medium text-amber-700 dark:text-amber-400'
                            : 'font-medium text-blue-600 dark:text-blue-400'
                        }
                      >
                        {typeLabel(item.type)}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">
                        {formatRelativeTime(item.created_at)}
                      </span>
                      {unread && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-medium text-blue-600 dark:text-blue-400">
                            Unread
                          </span>
                        </>
                      )}
                    </div>
                    <p
                      className={`mt-1 text-sm ${
                        unread
                          ? 'font-medium text-slate-900 dark:text-white'
                          : 'text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {item.message}
                    </p>
                  </div>

                  {unread && (
                    <button
                      type="button"
                      onClick={() => onMarkRead(item.id)}
                      className="flex shrink-0 items-center gap-1 whitespace-nowrap rounded-lg border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                    >
                      <Check className="h-3.5 w-3.5" />
                      <span>Mark read</span>
                    </button>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}
