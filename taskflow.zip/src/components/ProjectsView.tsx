import { useState, type FormEvent } from 'react';
import { FolderPlus, Pencil, Plus, Trash2, UserMinus, UserPlus } from 'lucide-react';
import { api, ApiError } from '../lib/api.ts';
import { formatDueDate, priorityTextColor } from '../lib/format.ts';
import type { Project, Task, User } from '../types/index.ts';
import { ConfirmModal } from './ConfirmModal.tsx';

interface ProjectsViewProps {
  projects: Project[];
  tasks: Task[];
  currentUser: User;
  onRefresh: () => Promise<void>;
  onCreateProjectTask: (projectId: string) => void;
  onEditTask: (task: Task) => void;
}

export function ProjectsView({
  projects,
  tasks,
  currentUser,
  onRefresh,
  onCreateProjectTask,
  onEditTask,
}: ProjectsViewProps) {
  const [selectedId, setSelectedId] = useState<string>(projects[0]?.id ?? '');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [projectName, setProjectName] = useState('');
  const [projectDesc, setProjectDesc] = useState('');
  const [memberEmail, setMemberEmail] = useState('');
  const [error, setError] = useState('');
  const [memberError, setMemberError] = useState('');
  const [saving, setSaving] = useState(false);
  const [confirmDeleteProject, setConfirmDeleteProject] = useState<Project | null>(null);

  const selectedProject =
    projects.find((p) => p.id === selectedId) ?? projects[0] ?? null;

  const projectTasks = selectedProject
    ? tasks.filter((t) => t.project_id === selectedProject.id)
    : [];

  const isOwner = selectedProject?.owner_id === currentUser.id;

  const openCreate = () => {
    setEditingProject(null);
    setProjectName('');
    setProjectDesc('');
    setError('');
    setShowCreateForm(true);
  };

  const openEdit = (p: Project) => {
    setEditingProject(p);
    setProjectName(p.project_name);
    setProjectDesc(p.description);
    setError('');
    setShowCreateForm(true);
  };

  const handleSaveProject = async (e: FormEvent) => {
    e.preventDefault();
    if (!projectName.trim()) {
      setError('Project name is required.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      if (editingProject) {
        await api.updateProject(editingProject.id, {
          project_name: projectName.trim(),
          description: projectDesc.trim(),
        });
      } else {
        const res = await api.createProject({
          project_name: projectName.trim(),
          description: projectDesc.trim(),
        });
        setSelectedId(res.project.id);
      }
      setShowCreateForm(false);
      await onRefresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Unable to save project.');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteProject = async () => {
    if (!confirmDeleteProject) return;
    setSaving(true);
    try {
      await api.deleteProject(confirmDeleteProject.id);
      setConfirmDeleteProject(null);
      setSelectedId('');
      await onRefresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Unable to delete project.');
    } finally {
      setSaving(false);
    }
  };

  const handleAddMember = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !memberEmail.trim()) return;
    setMemberError('');
    try {
      await api.addProjectMember(selectedProject.id, memberEmail.trim());
      setMemberEmail('');
      await onRefresh();
    } catch (err) {
      setMemberError(err instanceof ApiError ? err.message : 'Unable to add member.');
    }
  };

  const handleRemoveMember = async (memberId: string) => {
    if (!selectedProject) return;
    setMemberError('');
    try {
      await api.removeProjectMember(selectedProject.id, memberId);
      await onRefresh();
    } catch (err) {
      setMemberError(err instanceof ApiError ? err.message : 'Unable to remove member.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-lg font-semibold text-slate-900 dark:text-white">
            Team &amp; Personal Projects
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Organize shared tasks and assign work to project members.
          </p>
        </div>
        <button
          type="button"
          onClick={openCreate}
          className="flex items-center gap-2 whitespace-nowrap rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-700"
        >
          <FolderPlus className="h-4 w-4" />
          <span>New Project</span>
        </button>
      </div>

      {showCreateForm && (
        <form
          onSubmit={handleSaveProject}
          className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900"
        >
          <h3 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            {editingProject ? 'Edit Project' : 'Create Project'}
          </h3>
          {error && (
            <div
              role="alert"
              className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3.5 py-2 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-300"
            >
              {error}
            </div>
          )}
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label
                htmlFor="proj-name"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Project Name
              </label>
              <input
                id="proj-name"
                type="text"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                placeholder="e.g., Website Redesign"
                required
                className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-sm text-slate-900 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
            <div>
              <label
                htmlFor="proj-desc"
                className="block text-xs font-medium text-slate-700 dark:text-slate-300"
              >
                Description
              </label>
              <input
                id="proj-desc"
                type="text"
                value={projectDesc}
                onChange={(e) => setProjectDesc(e.target.value)}
                placeholder="Brief scope or goal"
                className="mt-1.5 w-full rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-sm text-slate-900 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
          </div>
          <div className="mt-4 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => setShowCreateForm(false)}
              className="rounded-lg border border-slate-200 px-3.5 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="rounded-lg bg-blue-600 px-4 py-1.5 text-xs font-semibold text-white hover:bg-blue-700 disabled:opacity-50"
            >
              {saving ? 'Saving...' : editingProject ? 'Save Project' : 'Create Project'}
            </button>
          </div>
        </form>
      )}

      {projects.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-10 text-center dark:border-slate-800 dark:bg-slate-900">
          <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
            No projects yet
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Create a project to group related tasks and invite team members by email.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          {/* Project selector list */}
          <div className="space-y-2 lg:col-span-4">
            {projects.map((p) => {
              const active = selectedProject?.id === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    setSelectedId(p.id);
                    setMemberError('');
                  }}
                  className={`w-full rounded-xl border p-4 text-left transition-colors ${
                    active
                      ? 'border-blue-600 bg-blue-50/40 dark:border-blue-500 dark:bg-blue-950/30'
                      : 'border-slate-200 bg-white hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-slate-700'
                  }`}
                >
                  <p className="truncate font-display text-sm font-semibold text-slate-900 dark:text-white">
                    {p.project_name}
                  </p>
                  <p className="mt-1 line-clamp-2 text-xs text-slate-500 dark:text-slate-400">
                    {p.description || 'No description'}
                  </p>
                  <div className="mt-3 flex items-center gap-2 font-mono text-xs text-slate-500 tabular-nums dark:text-slate-400">
                    <span>
                      {p.completed_tasks}/{p.total_tasks} tasks
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{p.members.length} members</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Selected project workspace */}
          {selectedProject && (
            <div className="space-y-6 lg:col-span-8">
              <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-100 pb-4 dark:border-slate-800">
                  <div>
                    <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-white">
                      {selectedProject.project_name}
                    </h3>
                    <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                      {selectedProject.description || 'No description provided.'}
                    </p>
                    <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
                      Owner: <span className="font-medium text-slate-700 dark:text-slate-200">{selectedProject.owner_name}</span>
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onCreateProjectTask(selectedProject.id)}
                      className="flex items-center gap-1.5 whitespace-nowrap rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-700"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      <span>Add Task</span>
                    </button>
                    {isOwner && (
                      <>
                        <button
                          type="button"
                          onClick={() => openEdit(selectedProject)}
                          className="rounded-lg border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                          aria-label="Edit project"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteProject(selectedProject)}
                          className="rounded-lg border border-slate-200 p-1.5 text-slate-600 hover:bg-red-50 hover:text-red-600 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-red-950/40 dark:hover:text-red-400"
                          aria-label="Delete project"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {/* Members section */}
                <div className="mt-4">
                  <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Project Members ({selectedProject.members.length})
                  </h4>

                  {isOwner && (
                    <form onSubmit={handleAddMember} className="mt-2.5 flex flex-wrap gap-2">
                      <input
                        type="email"
                        value={memberEmail}
                        onChange={(e) => setMemberEmail(e.target.value)}
                        placeholder="Invite registered user by email..."
                        aria-label="Member email address"
                        required
                        className="min-w-0 flex-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                      />
                      <button
                        type="submit"
                        className="flex items-center gap-1.5 whitespace-nowrap rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                      >
                        <UserPlus className="h-3.5 w-3.5" />
                        <span>Add Member</span>
                      </button>
                    </form>
                  )}

                  {memberError && (
                    <p role="alert" className="mt-2 text-xs text-red-600 dark:text-red-400">
                      {memberError}
                    </p>
                  )}

                  <ul className="mt-3 divide-y divide-slate-100 dark:divide-slate-800">
                    {selectedProject.members.map((m) => (
                      <li key={m.id} className="flex items-center justify-between py-2 text-sm">
                        <div className="min-w-0">
                          <span className="font-medium text-slate-900 dark:text-slate-100">
                            {m.name}
                          </span>
                          <span className="ml-2 text-xs text-slate-500 dark:text-slate-400">
                            {m.email}
                            {m.id === selectedProject.owner_id ? ' · Owner' : ''}
                          </span>
                        </div>
                        {isOwner && m.id !== selectedProject.owner_id && (
                          <button
                            type="button"
                            onClick={() => handleRemoveMember(m.id)}
                            className="rounded p-1 text-slate-400 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/40 dark:hover:text-red-400"
                            aria-label={`Remove ${m.name}`}
                          >
                            <UserMinus className="h-4 w-4" />
                          </button>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              </section>

              {/* Project tasks */}
              <section className="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                <div className="border-b border-slate-100 px-5 py-3.5 dark:border-slate-800">
                  <h4 className="font-display text-sm font-semibold text-slate-900 dark:text-white">
                    Project Tasks ({projectTasks.length})
                  </h4>
                </div>
                {projectTasks.length === 0 ? (
                  <p className="px-5 py-8 text-center text-xs text-slate-500 dark:text-slate-400">
                    No tasks in this project yet. Click Add Task above to create one.
                  </p>
                ) : (
                  <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                    {projectTasks.map((t) => (
                      <li
                        key={t.id}
                        className="flex items-center justify-between gap-4 px-5 py-3 hover:bg-slate-50 dark:hover:bg-slate-800/40"
                      >
                        <div className="min-w-0">
                          <button
                            type="button"
                            onClick={() => onEditTask(t)}
                            className="block truncate text-left text-sm font-medium text-slate-900 hover:text-blue-600 dark:text-slate-100 dark:hover:text-blue-400"
                          >
                            {t.title}
                          </button>
                          <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                            <span className={priorityTextColor(t.priority)}>{t.priority}</span>
                            <span aria-hidden="true">·</span>
                            <span>{t.status}</span>
                            <span aria-hidden="true">·</span>
                            <span>{t.assignee_name || 'Unassigned'}</span>
                          </div>
                        </div>
                        <span className="shrink-0 font-mono text-xs text-slate-500 tabular-nums dark:text-slate-400">
                          {formatDueDate(t.due_date)}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            </div>
          )}
        </div>
      )}

      <ConfirmModal
        open={Boolean(confirmDeleteProject)}
        title="Delete Project"
        description={`Are you sure you want to delete "${confirmDeleteProject?.project_name}"? Tasks inside it will become personal tasks.`}
        confirmLabel="Delete Project"
        destructive
        busy={saving}
        onConfirm={handleDeleteProject}
        onCancel={() => setConfirmDeleteProject(null)}
      />
    </div>
  );
}
