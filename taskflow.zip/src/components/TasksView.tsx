import { ArrowDownUp, CheckCircle2, Circle, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import type { TaskQueryParams } from '../lib/api.ts';
import { formatDueDate, priorityTextColor, statusTextColor } from '../lib/format.ts';
import type { Project, Task, TaskStatus } from '../types/index.ts';

interface TasksViewProps {
  tasks: Task[];
  projects: Project[];
  loading: boolean;
  filters: TaskQueryParams;
  onChangeFilters: (next: TaskQueryParams) => void;
  onCreateTask: () => void;
  onEditTask: (task: Task) => void;
  onUpdateStatus: (task: Task, nextStatus: TaskStatus) => void;
  onRequestDelete: (task: Task) => void;
}

export function TasksView({
  tasks,
  projects,
  loading,
  filters,
  onChangeFilters,
  onCreateTask,
  onEditTask,
  onUpdateStatus,
  onRequestDelete,
}: TasksViewProps) {
  const statusSegment = filters.overdue ? 'Overdue' : filters.status || 'All';

  const handleSegmentClick = (seg: string) => {
    if (seg === 'All') {
      onChangeFilters({ ...filters, status: undefined, overdue: false });
    } else if (seg === 'Overdue') {
      onChangeFilters({ ...filters, status: undefined, overdue: true });
    } else {
      onChangeFilters({ ...filters, status: seg, overdue: false });
    }
  };

  const resetFilters = () => {
    onChangeFilters({
      sort: 'due_date',
      order: 'asc',
    });
  };

  return (
    <div className="space-y-5">
      {/* Search and filter toolbar */}
      <section className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          {/* Segmented status filter */}
          <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
            {['All', 'Pending', 'In Progress', 'Completed', 'Overdue'].map((seg) => (
              <button
                key={seg}
                type="button"
                onClick={() => handleSegmentClick(seg)}
                className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                  statusSegment === seg
                    ? 'bg-white text-slate-900 shadow-xs dark:bg-slate-900 dark:text-white'
                    : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
              >
                {seg}
              </button>
            ))}
          </div>

          {/* Title search */}
          <div className="relative w-full lg:w-72">
            <Search
              className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="search"
              value={filters.search ?? ''}
              onChange={(e) => onChangeFilters({ ...filters, search: e.target.value })}
              placeholder="Search tasks by title..."
              aria-label="Search tasks by title"
              className="w-full rounded-lg border border-slate-200 bg-white py-2 pr-3 pl-9 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>
        </div>

        {/* Secondary filters & sorting */}
        <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-slate-100 pt-4 dark:border-slate-800">
          <select
            aria-label="Filter by priority"
            value={filters.priority ?? ''}
            onChange={(e) =>
              onChangeFilters({ ...filters, priority: e.target.value || undefined })
            }
            className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
          >
            <option value="">All Priorities</option>
            <option value="High">High Priority</option>
            <option value="Medium">Medium Priority</option>
            <option value="Low">Low Priority</option>
          </select>

          <select
            aria-label="Filter by project"
            value={filters.project_id ?? ''}
            onChange={(e) =>
              onChangeFilters({ ...filters, project_id: e.target.value || undefined })
            }
            className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
          >
            <option value="">All Projects</option>
            <option value="personal">Personal Only</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.project_name}
              </option>
            ))}
          </select>

          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span>Due:</span>
            <input
              type="date"
              aria-label="Due date from"
              value={filters.due_from ?? ''}
              onChange={(e) =>
                onChangeFilters({ ...filters, due_from: e.target.value || undefined })
              }
              className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs text-slate-700 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
            <span>to</span>
            <input
              type="date"
              aria-label="Due date to"
              value={filters.due_to ?? ''}
              onChange={(e) =>
                onChangeFilters({ ...filters, due_to: e.target.value || undefined })
              }
              className="rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 font-mono text-xs text-slate-700 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
          </div>

          <div className="ml-auto flex items-center gap-2">
            <select
              aria-label="Sort tasks by"
              value={filters.sort ?? 'created_at'}
              onChange={(e) =>
                onChangeFilters({
                  ...filters,
                  sort: e.target.value as 'due_date' | 'priority' | 'created_at',
                })
              }
              className="rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            >
              <option value="due_date">Sort: Due Date</option>
              <option value="priority">Sort: Priority</option>
              <option value="created_at">Sort: Created Date</option>
            </select>

            <button
              type="button"
              onClick={() =>
                onChangeFilters({
                  ...filters,
                  order: filters.order === 'asc' ? 'desc' : 'asc',
                })
              }
              className="flex items-center gap-1.5 whitespace-nowrap rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:bg-slate-800"
              aria-label="Toggle sort direction"
            >
              <ArrowDownUp className="h-3.5 w-3.5" />
              <span>{filters.order === 'asc' ? 'Asc' : 'Desc'}</span>
            </button>
          </div>
        </div>
      </section>

      {/* Task Table */}
      <section className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        {loading ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {Array.from({ length: 5 }).map((_, idx) => (
              <div key={idx} className="h-14 animate-pulse px-5 py-4" />
            ))}
          </div>
        ) : tasks.length === 0 ? (
          <div className="px-6 py-12 text-center">
            <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
              No tasks match your current filters
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Create a new task or adjust your search and filter criteria.
            </p>
            <div className="mt-5 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={resetFilters}
                className="whitespace-nowrap rounded-lg border border-slate-200 px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
              >
                Clear Filters
              </button>
              <button
                type="button"
                onClick={onCreateTask}
                className="flex items-center gap-1.5 whitespace-nowrap rounded-lg bg-blue-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-700"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Add Task</span>
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Desktop high-density table */}
            <div className="hidden overflow-x-auto md:block">
              <table className="w-full border-collapse text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/80 text-xs font-medium text-slate-500 dark:border-slate-800 dark:bg-slate-950/60 dark:text-slate-400">
                    <th className="py-3 pr-3 pl-5">Task</th>
                    <th className="px-3 py-3">Project</th>
                    <th className="px-3 py-3">Assignee</th>
                    <th className="px-3 py-3">Priority</th>
                    <th className="px-3 py-3">Status</th>
                    <th className="px-3 py-3 text-right">Due Date</th>
                    <th className="py-3 pr-5 pl-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {tasks.map((task) => {
                    const isCompleted = task.status === 'Completed';
                    return (
                      <tr
                        key={task.id}
                        className="transition-colors hover:bg-slate-50/80 dark:hover:bg-slate-800/40"
                      >
                        <td className="py-3 pr-3 pl-5">
                          <div className="flex items-center gap-3">
                            <button
                              type="button"
                              onClick={() =>
                                onUpdateStatus(task, isCompleted ? 'Pending' : 'Completed')
                              }
                              className="shrink-0 text-slate-400 transition-colors hover:text-emerald-600 focus-visible:outline-2 focus-visible:outline-blue-600"
                              aria-label={
                                isCompleted
                                  ? `Mark "${task.title}" pending`
                                  : `Complete "${task.title}"`
                              }
                            >
                              {isCompleted ? (
                                <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                              ) : (
                                <Circle className="h-4 w-4" />
                              )}
                            </button>
                            <div className="min-w-0">
                              <button
                                type="button"
                                onClick={() => onEditTask(task)}
                                className={`block max-w-md truncate text-left font-medium hover:text-blue-600 dark:hover:text-blue-400 ${
                                  isCompleted
                                    ? 'text-slate-400 line-through dark:text-slate-500'
                                    : 'text-slate-900 dark:text-slate-100'
                                }`}
                              >
                                {task.title}
                              </button>
                            </div>
                          </div>
                        </td>
                        <td className="px-3 py-3 text-xs text-slate-600 dark:text-slate-400">
                          {task.project_name || 'Personal'}
                        </td>
                        <td className="px-3 py-3 text-xs text-slate-600 dark:text-slate-400">
                          {task.assignee_name || 'Unassigned'}
                        </td>
                        <td className={`px-3 py-3 text-xs ${priorityTextColor(task.priority)}`}>
                          {task.priority}
                        </td>
                        <td className="px-3 py-3">
                          <select
                            aria-label={`Change status for ${task.title}`}
                            value={task.status}
                            onChange={(e) =>
                              onUpdateStatus(task, e.target.value as TaskStatus)
                            }
                            className={`rounded-md border border-slate-200 bg-white px-2 py-1 text-xs font-medium focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 ${statusTextColor(
                              task.status,
                              task.is_overdue
                            )}`}
                          >
                            <option value="Pending">
                              {task.is_overdue && task.status === 'Pending'
                                ? 'Pending (Overdue)'
                                : 'Pending'}
                            </option>
                            <option value="In Progress">
                              {task.is_overdue && task.status === 'In Progress'
                                ? 'In Progress (Overdue)'
                                : 'In Progress'}
                            </option>
                            <option value="Completed">Completed</option>
                          </select>
                        </td>
                        <td
                          className={`px-3 py-3 text-right font-mono text-xs tabular-nums ${
                            task.is_overdue
                              ? 'font-semibold text-red-600 dark:text-red-400'
                              : 'text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          {formatDueDate(task.due_date)}
                          {task.is_overdue ? ' · Overdue' : ''}
                        </td>
                        <td className="py-3 pr-5 pl-3 text-right">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => onEditTask(task)}
                              className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-100"
                              aria-label={`Edit ${task.title}`}
                            >
                              <Pencil className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onRequestDelete(task)}
                              className="rounded-md p-1.5 text-slate-500 hover:bg-red-50 hover:text-red-600 dark:text-slate-400 dark:hover:bg-red-950/40 dark:hover:text-red-400"
                              aria-label={`Delete ${task.title}`}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile stacked list (>= 360px) */}
            <ul className="divide-y divide-slate-100 md:hidden dark:divide-slate-800">
              {tasks.map((task) => {
                const isCompleted = task.status === 'Completed';
                return (
                  <li key={task.id} className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <button
                        type="button"
                        onClick={() => onEditTask(task)}
                        className={`text-left text-sm font-medium ${
                          isCompleted
                            ? 'text-slate-400 line-through dark:text-slate-500'
                            : 'text-slate-900 dark:text-slate-100'
                        }`}
                      >
                        {task.title}
                      </button>
                      <div className="flex shrink-0 items-center gap-1">
                        <button
                          type="button"
                          onClick={() => onEditTask(task)}
                          className="p-1.5 text-slate-500"
                          aria-label={`Edit ${task.title}`}
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onRequestDelete(task)}
                          className="p-1.5 text-slate-500 hover:text-red-600"
                          aria-label={`Delete ${task.title}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span className={priorityTextColor(task.priority)}>{task.priority}</span>
                      <span aria-hidden="true">·</span>
                      <span>{task.project_name || 'Personal'}</span>
                      <span aria-hidden="true">·</span>
                      <span
                        className={`font-mono tabular-nums ${
                          task.is_overdue ? 'font-semibold text-red-600 dark:text-red-400' : ''
                        }`}
                      >
                        {formatDueDate(task.due_date)}
                        {task.is_overdue ? ' (Overdue)' : ''}
                      </span>
                    </div>
                    <div className="mt-3">
                      <select
                        aria-label={`Status for ${task.title}`}
                        value={task.status}
                        onChange={(e) => onUpdateStatus(task, e.target.value as TaskStatus)}
                        className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
                      >
                        <option value="Pending">Pending</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                      </select>
                    </div>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </section>
    </div>
  );
}
