import { Bell, Menu, Plus } from 'lucide-react';
import type { ViewName } from '../types/index.ts';

const VIEW_LABELS: Record<ViewName, string> = {
  dashboard: 'Dashboard',
  tasks: 'Tasks',
  board: 'Kanban Board',
  calendar: 'Calendar',
  projects: 'Projects',
  analytics: 'Analytics',
  notifications: 'Notifications',
  settings: 'Profile & Settings',
  admin: 'Administration',
};

interface TopBarProps {
  currentView: ViewName;
  unreadCount: number;
  onOpenMobileMenu: () => void;
  onOpenNotifications: () => void;
  onCreateTask: () => void;
}

export function TopBar({
  currentView,
  unreadCount,
  onOpenMobileMenu,
  onOpenNotifications,
  onCreateTask,
}: TopBarProps) {
  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-4 border-b border-slate-200 bg-white/95 px-4 backdrop-blur-xs sm:px-6 dark:border-slate-800 dark:bg-slate-900/95">
      <div className="flex items-center gap-3 min-w-0">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden focus-visible:outline-2 focus-visible:outline-blue-600 dark:text-slate-300 dark:hover:bg-slate-800"
          aria-label="Open navigation menu"
        >
          <Menu className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-2 text-sm min-w-0">
          <span className="hidden text-slate-400 sm:inline dark:text-slate-500">Workspace</span>
          <span className="hidden text-slate-300 sm:inline dark:text-slate-700">/</span>
          <h1 className="truncate font-display text-base font-semibold text-slate-900 dark:text-white">
            {VIEW_LABELS[currentView]}
          </h1>
        </div>
      </div>

      <div className="flex items-center gap-3 shrink-0">
        <button
          type="button"
          onClick={onOpenNotifications}
          className="relative flex items-center gap-1.5 whitespace-nowrap shrink-0 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-blue-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
          aria-label={`Notifications (${unreadCount} unread)`}
        >
          <Bell className="h-4 w-4 text-slate-500 dark:text-slate-400" />
          <span className="hidden sm:inline">Alerts</span>
          {unreadCount > 0 && (
            <span className="font-mono text-xs font-semibold text-blue-600 tabular-nums dark:text-blue-400">
              ({unreadCount})
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={onCreateTask}
          className="flex items-center gap-1.5 whitespace-nowrap shrink-0 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-blue-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
        >
          <Plus className="h-4 w-4" aria-hidden="true" />
          <span>New Task</span>
        </button>
      </div>
    </header>
  );
}
