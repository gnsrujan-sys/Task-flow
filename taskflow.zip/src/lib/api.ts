import type {
  AdminProjectRow,
  AdminUserRow,
  AnalyticsData,
  NotificationItem,
  Project,
  ProjectMember,
  Task,
  TaskPriority,
  TaskStatus,
  User,
} from '../types/index.ts';

let inMemoryToken: string | null = null;

export function setAuthToken(token: string | null): void {
  inMemoryToken = token;
}

export function getAuthToken(): string | null {
  return inMemoryToken;
}

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers);
  if (!headers.has('Content-Type') && options.body) {
    headers.set('Content-Type', 'application/json');
  }
  if (inMemoryToken) {
    headers.set('Authorization', `Bearer ${inMemoryToken}`);
  }

  const response = await fetch(path, {
    ...options,
    headers,
  });

  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await response.json() : null;

  if (!response.ok) {
    const message =
      (data && typeof data.message === 'string' && data.message) ||
      `Request failed (${response.status})`;
    throw new ApiError(response.status, message);
  }

  return data as T;
}

export interface TaskQueryParams {
  search?: string;
  status?: string;
  priority?: string;
  project_id?: string;
  overdue?: boolean;
  due_from?: string;
  due_to?: string;
  sort?: 'due_date' | 'priority' | 'created_at';
  order?: 'asc' | 'desc';
}

export const api = {
  getBootstrapStatus: () =>
    request<{ adminClaimed: boolean }>('/api/auth/bootstrap-status'),

  claimAdmin: (payload: { name: string; email: string; password: string }) =>
    request<{ token: string; user: User }>('/api/auth/claim-admin', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  register: (payload: { name: string; email: string; password: string }) =>
    request<{ token: string; user: User }>('/api/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  login: (payload: { email: string; password: string }) =>
    request<{ token: string; user: User }>('/api/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  getMe: () => request<{ user: User }>('/api/me'),

  updateMe: (payload: { name?: string; currentPassword?: string; newPassword?: string }) =>
    request<{ user: User }>('/api/me', {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),

  getTasks: (params: TaskQueryParams = {}) => {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([key, val]) => {
      if (val !== undefined && val !== '' && val !== false) {
        qs.set(key, String(val));
      }
    });
    const query = qs.toString();
    return request<{ tasks: Task[] }>(`/api/tasks${query ? `?${query}` : ''}`);
  },

  createTask: (payload: {
    title: string;
    description?: string;
    priority?: TaskPriority;
    status?: TaskStatus;
    due_date?: string | null;
    project_id?: string | null;
    assigned_to?: string | null;
  }) =>
    request<{ task: Task }>('/api/tasks', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateTask: (
    id: string,
    payload: Partial<{
      title: string;
      description: string;
      priority: TaskPriority;
      status: TaskStatus;
      due_date: string | null;
      project_id: string | null;
      assigned_to: string | null;
    }>
  ) =>
    request<{ task: Task }>(`/api/tasks/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),

  deleteTask: (id: string) =>
    request<{ message: string }>(`/api/tasks/${id}`, { method: 'DELETE' }),

  getProjects: () => request<{ projects: Project[] }>('/api/projects'),

  createProject: (payload: { project_name: string; description?: string }) =>
    request<{ project: Project }>('/api/projects', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateProject: (id: string, payload: { project_name?: string; description?: string }) =>
    request<{ message: string }>(`/api/projects/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),

  deleteProject: (id: string) =>
    request<{ message: string }>(`/api/projects/${id}`, { method: 'DELETE' }),

  addProjectMember: (projectId: string, email: string) =>
    request<{ member: ProjectMember }>(`/api/projects/${projectId}/members`, {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),

  removeProjectMember: (projectId: string, memberId: string) =>
    request<{ message: string }>(`/api/projects/${projectId}/members/${memberId}`, {
      method: 'DELETE',
    }),

  getAnalytics: () => request<AnalyticsData>('/api/analytics'),

  getNotifications: () =>
    request<{ notifications: NotificationItem[]; unreadCount: number }>('/api/notifications'),

  markNotificationRead: (id: string) =>
    request<{ message: string }>(`/api/notifications/${id}/read`, { method: 'PUT' }),

  markAllNotificationsRead: () =>
    request<{ message: string }>('/api/notifications/read-all', { method: 'PUT' }),

  seedSampleWorkspace: () =>
    request<{ message: string }>('/api/workspace/seed-sample', { method: 'POST' }),

  adminGetUsers: (search = '') =>
    request<{ users: AdminUserRow[] }>(
      `/api/admin/users${search ? `?search=${encodeURIComponent(search)}` : ''}`
    ),

  adminUpdateUser: (id: string, payload: { is_active?: boolean; role?: 'user' | 'admin' }) =>
    request<{ user: User }>(`/api/admin/users/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    }),

  adminGetProjects: () => request<{ projects: AdminProjectRow[] }>('/api/admin/projects'),

  adminDeleteProject: (id: string) =>
    request<{ message: string }>(`/api/admin/projects/${id}`, { method: 'DELETE' }),
};
