import type { TaskPriority, TaskStatus } from '../types/index.ts';

export function formatDueDate(dateStr: string | null): string {
  if (!dateStr) return 'No due date';
  const [y, m, d] = dateStr.split('-').map(Number);
  if (!y || !m || !d) return dateStr;
  const date = new Date(Date.UTC(y, m - 1, d));
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC',
  });
}

export function formatRelativeTime(isoString: string): string {
  const date = new Date(isoString);
  const diffMs = Date.now() - date.getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export function statusTextColor(status: TaskStatus, isOverdue: boolean): string {
  if (isOverdue) return 'text-red-600 dark:text-red-400';
  switch (status) {
    case 'Completed':
      return 'text-emerald-700 dark:text-emerald-400';
    case 'In Progress':
      return 'text-amber-700 dark:text-amber-400';
    default:
      return 'text-slate-600 dark:text-slate-400';
  }
}

export function priorityTextColor(priority: TaskPriority): string {
  switch (priority) {
    case 'High':
      return 'text-red-600 dark:text-red-400 font-medium';
    case 'Medium':
      return 'text-amber-700 dark:text-amber-400 font-medium';
    case 'Low':
      return 'text-slate-500 dark:text-slate-400';
  }
}

export function todayIsoDate(): string {
  return new Date().toISOString().slice(0, 10);
}
