export type UserRole = 'user' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  is_active: number;
  created_at: string;
}

export type TaskPriority = 'High' | 'Medium' | 'Low';
export type TaskStatus = 'Pending' | 'In Progress' | 'Completed';

export interface Task {
  id: string;
  title: string;
  description: string;
  user_id: string;
  assigned_to: string | null;
  project_id: string | null;
  priority: TaskPriority;
  status: TaskStatus;
  due_date: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
  creator_name: string;
  assignee_name: string | null;
  project_name: string | null;
  is_overdue: boolean;
}

export interface ProjectMember {
  id: string;
  name: string;
  email: string;
  added_at: string;
}

export interface Project {
  id: string;
  project_name: string;
  description: string;
  owner_id: string;
  owner_name: string;
  owner_email: string;
  created_at: string;
  members: ProjectMember[];
  total_tasks: number;
  completed_tasks: number;
}

export interface NotificationItem {
  id: string;
  user_id: string;
  message: string;
  type: 'deadline' | 'assigned' | 'status_changed';
  task_id: string | null;
  is_read: number;
  created_at: string;
}

export interface ActivityLog {
  id: string;
  user_id: string;
  actor_name: string;
  action: string;
  target_title: string;
  project_id: string | null;
  created_at: string;
}

export interface AnalyticsData {
  counts: {
    total: number;
    pending: number;
    inProgress: number;
    completed: number;
    overdue: number;
  };
  byStatus: Record<TaskStatus, number>;
  byPriority: Record<TaskPriority, number>;
  weeklyCompleted: Array<{ label: string; count: number }>;
  upcomingTasks: Task[];
  recentActivity: ActivityLog[];
}

export interface AdminUserRow extends User {
  task_count: number;
  owned_projects: number;
}

export interface AdminProjectRow {
  id: string;
  project_name: string;
  description: string;
  owner_id: string;
  owner_name: string;
  owner_email: string;
  member_count: number;
  task_count: number;
  created_at: string;
}

export type ViewName =
  | 'dashboard'
  | 'tasks'
  | 'board'
  | 'calendar'
  | 'projects'
  | 'analytics'
  | 'notifications'
  | 'settings'
  | 'admin';
